export interface Book {
  id: number;
  title: string;
  content: string;
}
